import {getItems, getItemById, addItem} from "../database/dynamo.js"


 const getProducts = async (req,res) => {
    try {
        const data = await getItems();
        res.status(200).json({
            status: "success",
            payload: data
        })
    } catch (error) {
        res.status(500).json({
            status: "error",
            message: "Error en obtener productos",
            error: error.message
          }); 
    }
}



const addProduct = async (req,res) => {
    try {
        const product = req.body;
        const response = await addItem(product);
        res.status(200).json({
            status:"success",
            payload: data
        })
    } catch (error) {
        res.status(500).json({
            status: "error",
            message: "Error en obtener productos",
            error: error.message
          }); 
    }
}

export {
    getProducts,
    addProduct
}