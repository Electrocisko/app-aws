import AWS from "aws-sdk";
import { nanoid } from "nanoid";

const REGION = process.env.AWS_DEFAULT_REGION;

console.log(REGION);

AWS.config.update({
  region: REGION,
});

const dynamoClient = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "productsDB";

const getItems = async () => {
  const params = {
    TableName: TABLE_NAME,
  };
  const items = await dynamoClient.scan(params).promise();
  return items;
};

const getItemById = async (id) => {
  const params = {
    TableName: TABLE_NAME,
    Key: {
      product_id: id,
    },
  };
  const response = await dynamoClient.get(params).promise();
  return response;
};

const addItem = async (product) => {
  product.product_id = nanoid();
  const params = {
    TableName: TABLE_NAME,
    Item: product,
  };
  const data = await dynamoClient.put(params).promise();
  return data;
};

export { getItems,getItemById, addItem };
